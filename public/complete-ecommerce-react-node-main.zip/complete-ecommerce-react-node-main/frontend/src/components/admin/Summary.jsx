const Summary = () => {
  return <h2>Summary</h2>;
};

export default Summary;
