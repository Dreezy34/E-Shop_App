const Users = () => {
  return <h2>Users</h2>;
};

export default Users;
