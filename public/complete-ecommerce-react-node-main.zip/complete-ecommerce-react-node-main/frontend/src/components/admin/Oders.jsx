const Orders = () => {
  return <h2>Orders</h2>;
};

export default Orders;
<h2>Orders</h2>;
